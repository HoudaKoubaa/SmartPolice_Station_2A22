#include "connection.h"

Connection::Connection()
{

}

bool Connection::createconnect()
{bool test=false;
QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
db.setDatabaseName("elyes");
db.setUserName("sgbd");//inserer nom de l'utilisateur
db.setPassword("sgbd");//inserer mot de passe de cet utilisateur

if (db.open())
test=true;





    return  test;
}
